# SPDX-FileCopyrightText: 2015-2023 Espressif Systems (Shanghai) CO LTD
# SPDX-License-Identifier: Apache-2.0


import os
import queue  # noqa: F401
import sys
import time

from esp_pylib.logger import log
from serial.tools.miniterm import Console  # noqa: F401

from .console_parser import ConsoleParser  # noqa: F401
from .constants import CMD_STOP
from .constants import TAG_CMD
from .stoppable_thread import StoppableThread


class ConsoleReader(StoppableThread):
    """Read input keys from the console and push them to the queue,
    until stopped.
    """

    def __init__(self, console, event_queue, cmd_queue, parser):
        # type: (Console, queue.Queue, queue.Queue, ConsoleParser) -> None
        super().__init__()
        self.console = console
        self.event_queue = event_queue
        self.cmd_queue = cmd_queue
        self.parser = parser
        self.cmd_stop_count = 0
        if sys.platform == 'win32':
            # This is a workaround for multi-byte characters causing the console to be killed by OS.
            # Miniterm is setting the code page to UTF-8 which in combination with multibyte Unicode characters
            # results in Critical Error in Windows: https://github.com/espressif/esp-idf/issues/12162
            # Note: UTF-8 characters seem to work even without this setting
            import ctypes

            ctypes.windll.kernel32.SetConsoleOutputCP(console._saved_ocp)
            ctypes.windll.kernel32.SetConsoleCP(console._saved_icp)

    def run(self):
        # type: () -> None
        self.console.setup()
        if sys.platform != 'win32':
            # Use non-blocking busy read to avoid using insecure TIOCSTI from console.cancel().
            # TIOCSTI is not supported on kernels newer than 6.2.
            import termios

            new = termios.tcgetattr(self.console.fd)
            # new[6] - 'cc': a list of the tty special characters
            new[6][termios.VMIN] = 0  # minimum bytes to read
            new[6][termios.VTIME] = 2  # timer of 0.1 second granularity
            termios.tcsetattr(self.console.fd, termios.TCSANOW, new)
        try:
            while self.alive:
                try:
                    if os.name == 'nt':
                        # Windows kludge: because the console.cancel() method doesn't
                        # seem to work to unblock getkey() on the Windows implementation.
                        #
                        # So we only call getkey() if we know there's a key waiting for us.
                        import msvcrt

                        while not msvcrt.kbhit() and self.alive:  # type: ignore
                            time.sleep(0.1)
                        if not self.alive:
                            break
                    c = self.console.getkey()
                except KeyboardInterrupt:
                    c = '\x03'
                if c:
                    ret = self.parser.parse(c)
                    if ret is not None:
                        (tag, cmd) = ret
                        # stop command should be executed last
                        if tag == TAG_CMD and cmd != CMD_STOP:
                            self.cmd_queue.put(ret)
                        elif cmd == CMD_STOP:
                            self.cmd_stop_count += 1
                            if self.cmd_stop_count >= 2:
                                log.print('Multiple stop commands received, forcing quit monitor', style='yellow')
                                # event_queue normally contains data from the chip. Moving the CMD_STOP to the cmd_queue
                                # should make the monitor quit sooner, as this takes priority and we assume the queue is
                                # usually empty. This is not a proper force quit, as there might be some data in the
                                # cmd_queue as well, only an escalation of the stop command.
                                self.cmd_queue.put(ret)
                            else:
                                if self.event_queue.qsize() > 100:
                                    log.note(
                                        'IDF Monitor will decode all received data and close. '
                                        'If you want to stop the monitor immediately, press exit key again.'
                                    )
                                self.event_queue.put(ret)
                        else:
                            self.event_queue.put(ret)

        finally:
            self.console.cleanup()
